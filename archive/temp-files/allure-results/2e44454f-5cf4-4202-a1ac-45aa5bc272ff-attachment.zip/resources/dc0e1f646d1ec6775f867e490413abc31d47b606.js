(function(interdeal){
	interdeal.ClassManager = class{
		constructor(){
			if(!this.isInit){
				this.bodyDataSet    =  document.body.dataset;
				this.bodyClasslist  =  document.body.classList;
				this.INDWrapClasslist  =  interdeal.INDWrap.classList;
				this.INDWrapDataset  =  interdeal.INDWrap.dataset;
				this.docDataset     = document.documentElement.dataset;
				this.excludes = ['indRatio'];
				this.indREGEX = /^ind/g;
				this.storage = {
					doc  : [],
					body : []
				}
				this.init();
			}
			return this;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///                                                                  initializers                                                                  ///
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		init(){
			if( !this.isInit ){
				/**
				 * move this to storage
				 */
				const staticCls    = [ /*'INDhasDragTooltip'*/ ];//check when this class is applied.
				const bodyClassStr = [
					`IND${ interdeal.isDesktop ? 'Desktop': 'Mobile' }`, 
					`IND${ interdeal?.browser?.name?.trim() || 'chrome' }`,
					`INDlangdir${ interdeal.langDir.toUpperCase().trim() || interdeal.langDir.toUpperCase().trim() }`,
					`IND${ interdeal.a11y.camelCase ( `position-${ interdeal.menuPos  || 'left' }`).trim() }`
				];

				/**
				 * use this.storage 
				 */
				[
					... Array.from( this.bodyClasslist ), 
					... Array.from( this.INDWrapClasslist ), 
					... staticCls , 
					... bodyClassStr
				].forEach( c => {
					if( /^IND/g.test( c ) && !this.excludes.includes( c ) ) { 
						// dataset[ parseATTR( c ) ] = c;
						this.add( c )
					}
				});
				this.isInit = true;
			}else{
				this.restore();
			}
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///                                                                   functions                                                                    ///
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		/**
		 * restores 
		 */
		restore( ) {
			this.bodyDataSet    	= document.body.dataset;
			this.bodyClasslist  	= document.body.classList;
			this.INDWrapClasslist   = interdeal.INDWrap.classList;
			this.INDWrapDataset     = interdeal.INDWrap.dataset;
			let data = [ ...this.storage.doc, ...this.storage.body ];
			if( data.length ){
				data
					.filter( ( o ) => {
						return /^ind/.test( o.key ) && !this.excludes.includes( o.key );
					})
					.forEach( ( o ) => {
						if(o.root){
							this.docDataset[o.key] = o.value;
						}
						this.bodyClasslist.add( o.value );
						this.INDWrapClasslist.add( o.value );
						this.bodyDataSet[o.key] = o.value;
						this.INDWrapDataset[o.key] = o.value;
					});
			}
		}

		/**
		 * Adds a class to the class manager.
		 *
		 * @param {string} cls - The class to be added.
		 * @param {boolean} [isAddToRoot=false] - Whether to add the class to the root.
		 */
		add( cls , isAddToRoot = false ) {
			let self = this || interdeal.classManager;
			if( !cls ) return;
			let key = self.parseATTR ( cls );
			if( isAddToRoot && !self.isExistInArr( cls,self.storage.doc ) ){
				self.storage.doc.push( { key , value : cls , root : true} );
				self.docDataset[ key ] = cls;
			}

			if(self.isExistInArr( cls ,self.storage.body )) return;
			self.storage.body.push( { key , value : cls } );
			self.bodyDataSet[ key ] = cls;
			self.INDWrapDataset[ key ] = cls;
			self.bodyClasslist.add( cls );
			self.INDWrapClasslist.add( cls );
		}

		/**
		 * removes class from dataset and fropm classlist of body.
		 * @param { String } cls class to remove.
		 */
		remove( cls , isAddToRoot = false ) {
			let self = this || interdeal.classManager;
			if(!cls) return;
			let key =  self.parseATTR( cls );
			if( isAddToRoot ){
				let docIndex = self.storage.doc.findIndex( o => o.key == key );
				if(docIndex >= 0){
					self.storage.doc.splice( docIndex ,1 );
					delete self.docDataset[ key ];
				}
			}
			let bodyIndex = self.storage.body.findIndex( o => o.key == key );
			if(bodyIndex >= 0){
				self.storage.body.splice( bodyIndex ,1 );
			}

			delete self.bodyDataSet[ key ];
			delete self.INDWrapDataset[ key ];
			self.bodyClasslist.remove( cls );
			self.INDWrapClasslist.remove( cls );
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		///                                                                misc. functions                                                                 ///
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		parseATTR( str ){
			return str.replace(/\-/g, '' ).toLowerCase();
		}

		isExistInArr(cls, arr){
			return arr.findIndex( o => cls == o.value ) >= 0;
		}
	}
	if(interdeal.classManager ){
		interdeal.classManager.restore();
	}else{
		interdeal.classManager = new interdeal.ClassManager();
		interdeal.a11y.classStorage = () => interdeal.classManager;
		interdeal.classManager.init();
	}
})(interdeal)



